"""Check every number in the manuscript tables against the campaign files.

The declaration of AI use in this article states that the authors verified
every reported number by re-running the released code.  This script is what
makes that statement checkable rather than merely asserted: it parses the
result tables out of the manuscript, recomputes each cell from the stored
campaign data, and reports any cell that disagrees beyond tolerance.

    python tools/verify_manuscript.py            # check
    python tools/verify_manuscript.py --tol 5e-3 # tighter

Exit status is non-zero if any cell fails, so it can be run in CI.
"""

from __future__ import annotations

import argparse
import pathlib
import re
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "examples"))

MD = ROOT / "PAPER_SoftwareX_draft.md"
ORDER = ["PD", "LQR", "ZVD", "SMC", "HSMC"]

# caption fragment -> (campaign, column metric keys)
TABLES = [
    ("**Reference campaign**", "reference",
     ["ise_pos", "peak_swing", "residual_swing", "settle_time",
      "effort", "chatter", "bound_ok"]),
    ("**Stress campaign**", "stress",
     ["ise_pos", "peak_swing", "residual_swing", "effort", "chatter", "bound_ok"]),
]

NUM = re.compile(r"^([<>]?)\s*([-+]?\d*\.?\d+)(?:·10⁻?([\d⁰¹²³⁴⁵⁶⁷⁸⁹]+))?")
SUP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")


def parse_cell(txt):
    """Return a float, or None if the cell is not a plain number."""
    t = txt.strip()
    if not t:
        return None
    m = re.match(r"^(\d+)/(\d+)$", t)                     # 461/500
    if m:
        return int(m.group(1)) / int(m.group(2))
    t = t.replace(" c", "").replace(">", "").strip()      # censored marker
    m = re.match(r"^([-+]?\d*\.?\d+)·10(⁻?)([⁰¹²³⁴⁵⁶⁷⁸⁹]+)$", t)
    if m:
        e = int(m.group(3).translate(SUP)) * (-1 if m.group(2) else 1)
        return float(m.group(1)) * 10.0 ** e
    m = re.match(r"^[-+]?\d*\.?\d+$", t)
    return float(t) if m else None


def load_campaign(name):
    from summarise_batch import load as load_batch
    if name in ("reference", "stress", "dryden", "calm", "stress_retuned"):
        return load_batch(name)
    z = np.load(ROOT / "run_sp2" / "spatial_paired.npz")
    out = {}
    for tag in z.files:
        c, k = tag.split("__")
        out.setdefault(c, {})[k] = z[tag]
    return out


def tables_from(md):
    """Yield (caption, rows) for every markdown table in the manuscript."""
    lines = md.split("\n")
    i = 0
    while i < len(lines):
        if lines[i].strip().startswith("|"):
            start = i
            while i < len(lines) and lines[i].strip().startswith("|"):
                i += 1
            caption = ""
            for j in range(start - 1, max(start - 4, -1), -1):
                if lines[j].strip():
                    caption = lines[j]
                    break
            yield caption, lines[start:i]
        i += 1


EXPECTED_CELLS = 65


def check(tol):
    md = MD.read_text()
    tabs = list(tables_from(md))
    failures, checked, skipped = [], 0, []

    for frag, campaign, keys in TABLES:
        tab = next((t for c, t in tabs if frag in c), None)
        if tab is None:
            failures.append(f"table for {frag!r} not found in the manuscript")
            continue
        data = load_campaign(campaign)
        for row in tab[2:]:
            cells = [c.strip() for c in row.strip().strip("|").split("|")]
            name = cells[0].strip()
            if name not in ORDER:
                continue
            for k, cell in zip(keys, cells[1:]):
                want = parse_cell(cell)
                if want is None:
                    continue
                got = float(np.nanmean(data[name][k]))
                checked += 1
                rel = abs(got - want) / max(abs(got), 1e-12)
                if rel > tol:
                    failures.append(
                        f"{campaign}/{name}/{k}: manuscript {want:g}, "
                        f"recomputed {got:g}  (rel {rel:.2%})")

    # re-tuned stress table: "11.90 → 10.04" and "0/500 → 0/500"
    tab = next((t for c, t in tabs if "re-tuned on the stress nominal" in c
                or "an equal budget" in c), None)
    if tab is None:
        tab = next((t for c, t in tabs if "frozen → re-tuned" in "".join(t)), None)
    if tab is not None:
        fro, ret = load_campaign("stress"), load_campaign("stress_retuned")
        for row in tab[2:]:
            cells = [c.strip() for c in row.strip().strip("|").split("|")]
            name = cells[0]
            if name not in ORDER:
                continue
            for cell, key in zip(cells[1:3], ("peak_swing", "bound_ok")):
                parts = [p.strip() for p in cell.split("→")]
                if len(parts) != 2:
                    continue
                for p, src in zip(parts, (fro, ret)):
                    want = parse_cell(p)
                    if want is None:
                        continue
                    got = float(np.nanmean(src[name][key]))
                    checked += 1
                    rel = abs(got - want) / max(abs(got), 1e-12)
                    if rel > tol:
                        failures.append(
                            f"stress re-tune/{name}/{key}: manuscript {want:g}, "
                            f"recomputed {got:g}  (rel {rel:.2%})")

    # spatial campaign table
    tab = next((t for c, t in tabs if "six-factor design" in c
                or "spatial" in c.lower()), None)
    if tab is not None and not (ROOT / "run_sp2" / "spatial_paired.npz").exists():
        skipped.append("spatial campaign table: run_sp2/spatial_paired.npz is "
                       "missing. Run examples/run_spatial_campaign.py --n 150")
    if tab is not None and (ROOT / "run_sp2" / "spatial_paired.npz").exists():
        data = load_campaign("spatial")
        keys = ["ise_pos", "peak_swing", "residual_swing", "peak_yaw",
                "effort", "chatter", "bound_ok"]
        for row in tab[2:]:
            cells = [c.strip() for c in row.strip().strip("|").split("|")]
            if cells[0] not in ORDER:
                continue
            for k, cell in zip(keys, cells[1:]):
                want = parse_cell(cell)
                if want is None:
                    continue
                got = float(np.nanmean(data[cells[0]][k]))
                checked += 1
                rel = abs(got - want) / max(abs(got), 1e-12)
                if rel > tol:
                    failures.append(
                        f"spatial/{cells[0]}/{k}: manuscript {want:g}, "
                        f"recomputed {got:g}  (rel {rel:.2%})")

    print(f"cells checked: {checked} of {EXPECTED_CELLS} expected"
          f"   tolerance: {tol:.1%}")
    if skipped:
        print("\nNOT CHECKED:")
        for sk in skipped:
            print("  -", sk)
    if failures:
        print(f"\nFAILURES ({len(failures)}):")
        for f in failures:
            print("  -", f)
    if failures or skipped:
        # A verification tool that stays silent about what it could not check
        # is worse than no tool: it converts a gap into a green tick.
        print("\nINCOMPLETE: not every table in the manuscript was verified."
              if skipped and not failures else "")
        return 1
    if checked < EXPECTED_CELLS:
        print(f"\nINCOMPLETE: expected {EXPECTED_CELLS} cells, checked {checked}.")
        return 1
    print("\nevery table cell in the manuscript matches the campaign files.")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tol", type=float, default=1e-2)
    sys.exit(check(ap.parse_args().tol))
