"""Fixed-step integrators.

A fixed step is used deliberately.  An adaptive solver silently changes the
effective sampling of a discontinuous or near-discontinuous control law, so two
controllers compared under an adaptive solver are not compared under the same
conditions.  The step is recorded in the ledger, and
``tests/test_convergence.py`` checks that the reported metrics are converged in
it.
"""

from __future__ import annotations

import numpy as np


def rk4(f, t, x, dt, *args):
    k1 = f(t, x, *args)
    k2 = f(t + 0.5 * dt, x + 0.5 * dt * k1, *args)
    k3 = f(t + 0.5 * dt, x + 0.5 * dt * k2, *args)
    k4 = f(t + dt, x + dt * k3, *args)
    return x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def simulate(plant, controller, manoeuvre, wind=None, dt=2.0e-3,
             control_dt=1.0e-2, force_fn=None):
    """Run one closed-loop simulation.

    The controller is evaluated on its own (slower) grid and held between
    updates, which is what a real drive does and which prevents a controller
    from buying performance with an unrealistically fast loop.
    """
    n = int(round(manoeuvre.t_total / dt)) + 1
    t = np.arange(n) * dt
    x = np.array(plant.initial_state(), float)
    controller.reset(plant, manoeuvre)

    X = np.empty((n, plant.nx))
    U = np.empty((n, plant.nu))
    every = max(1, int(round(control_dt / dt)))
    u = controller(0.0, x)

    for k in range(n):
        if k % every == 0:
            u = np.asarray(controller(t[k], x), float)
        X[k] = x
        U[k] = u
        if k == n - 1:
            break
        d = force_fn(t[k], x, wind) if force_fn is not None else np.zeros(3)
        x = rk4(plant.dynamics, t[k], x, dt, u, d)
        if not np.all(np.isfinite(x)):
            X[k + 1:] = np.nan
            U[k + 1:] = np.nan
            break
    return t, X, U


def drag_force(plant):
    """Quasi-steady drag, with the yaw moment of an eccentric centre of pressure.

    A bluff payload does not present its centroid to the wind, so the drag
    resultant acts through a point offset from it and the load carries a yaw
    moment as well as a force.  Plants that declare ``cp_ecc`` and ``width`` get
    that moment; plants that do not (the planar crane has no yaw coordinate) get
    a pure force, exactly as before.
    """
    rho = 1.225
    cd = getattr(plant.p, "cd", 1.2)
    area = getattr(plant.p, "area", 6.0)
    lever = getattr(plant.p, "cp_ecc", 0.0) * getattr(plant.p, "width", 0.0)

    def fn(t, x, wind):
        if wind is None:
            return np.zeros(3)
        v = wind.speed(t)
        f = 0.5 * rho * cd * area * v * abs(v)
        return np.array([f, 0.0, f * lever])

    return fn
