"""Paired statistics for the campaign results.

Only paired procedures are provided.  An unpaired t-test on two 500-sample
clouds drawn from the same uncertainty design would throw away the pairing that
the design was built to create, and would usually be less powerful by an order
of magnitude.
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
from scipy import stats as sps


def paired_summary(a: np.ndarray, b: np.ndarray,
                   n_boot: int = 10000, seed: int = 12345) -> Dict[str, float]:
    """Compare metric arrays ``a`` and ``b`` sample by sample."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    d = a - b
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, d.size, size=(n_boot, d.size))
    boot = d[idx].mean(axis=1)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    try:
        w = sps.wilcoxon(a, b, zero_method="zsplit")
        pval = float(w.pvalue)
    except ValueError:
        pval = float("nan")
    sd = d.std(ddof=1)
    return {
        "n": int(d.size),
        "rank_biserial": rank_biserial(a, b),
        "mean_a": float(a.mean()),
        "mean_b": float(b.mean()),
        "mean_diff": float(d.mean()),
        "ci_low": float(lo),
        "ci_high": float(hi),
        "wilcoxon_p": pval,
        "cohen_dz": float(d.mean() / sd) if sd > 0 else float("nan"),
        "win_rate": float(np.mean(a < b)),
    }


def rank_biserial(a: np.ndarray, b: np.ndarray) -> float:
    """Matched-pairs rank-biserial correlation.

    The effect size that belongs with a Wilcoxon signed-rank test.  Cohen's
    ``d_z`` assumes normal differences, which the metric distributions here do
    not have; reporting a parametric effect size next to a non-parametric test
    is a mismatch a careful reader will notice.
    """
    d = np.asarray(a, float) - np.asarray(b, float)
    d = d[np.isfinite(d) & (d != 0)]
    if d.size == 0:
        return float("nan")
    r = sps.rankdata(np.abs(d))
    return float((r[d > 0].sum() - r[d < 0].sum()) / r.sum())


def mcnemar(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    """Paired test for a binary outcome measured on the same samples."""
    a = np.asarray(a, float).astype(bool)
    b = np.asarray(b, float).astype(bool)
    n01 = int(np.sum(a & ~b))
    n10 = int(np.sum(~a & b))
    stat = (abs(n01 - n10) - 1) ** 2 / max(n01 + n10, 1)
    return {"a_only": n01, "b_only": n10, "statistic": float(stat),
            "p": float(sps.chi2.sf(stat, 1))}


def bound_sensitivity(peak_swing: np.ndarray,
                      thresholds=(3.0, 4.0, 4.8, 6.0, 7.0, 10.0)) -> Dict[float, int]:
    """Bound satisfaction as a function of the declared limit.

    A benchmark whose headline metric depends on an undeclared threshold is
    one question away from collapsing; reporting the whole curve costs nothing.
    """
    x = np.asarray(peak_swing, float)
    return {float(t): int(np.sum(x <= t)) for t in thresholds}


def running_mean_convergence(x: np.ndarray, tol: float = 0.01) -> Tuple[int, bool]:
    """Smallest prefix length whose mean is within ``tol`` (relative) of the full mean."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return 0, False
    full = x.mean()
    run = np.cumsum(x) / np.arange(1, x.size + 1)
    if full == 0:
        return x.size, True
    within = np.abs(run - full) <= tol * abs(full)
    tail = np.where(~within)[0]
    n_req = int(tail[-1] + 2) if tail.size else 1
    return min(n_req, x.size), n_req <= x.size
