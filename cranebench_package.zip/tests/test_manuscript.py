"""The manuscript tables must agree with the campaign files.

Marked slow because it needs the campaign result files; skipped when they are
absent, so a fresh checkout still gets a green suite.
"""

import pathlib
import subprocess
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]


@pytest.mark.skipif(not (ROOT / "run_batch" / "reference_metrics.npz").exists(),
                    reason="campaign result files not present")
def test_manuscript_tables_match_the_campaign_files():
    r = subprocess.run([sys.executable, str(ROOT / "tools" / "verify_manuscript.py")],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
