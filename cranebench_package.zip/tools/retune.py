"""Re-tune every baseline on the stress nominal, under a declared tuning budget.

The campaigns of Section 3.2 use gains tuned once on the benign nominal.  That
protocol favours feedforward over feedback whenever the evaluation point moves,
so it is a candidate explanation for the rank reversal observed under the
aggressive transfer.  This script repeats the tuning at the stress nominal so
that the two can be told apart.

The budget is the point.  Every controller gets a grid over its two principal
gains with exactly ``NGRID`` evaluations, scored by one frozen objective on one
deterministic wind-free run.  Equal budget, equal objective, equal operating
point -- so any remaining difference is the controller, not the attention it
received.
"""

from __future__ import annotations

import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cranebench.controllers import HSMC, LQR, PD, SMC, ZVD   # noqa: E402
from cranebench.reference import Manoeuvre                   # noqa: E402
from cranebench.runner import Campaign, run_single           # noqa: E402

NGRID = 24          # evaluations per controller -- the declared tuning budget
OBJECTIVE = "peak_swing + 4 * residual_swing"

STRESS = Manoeuvre(distance=20.0, t_ramp=10.0, t_total=30.0, kind="trapezoid")

GRIDS = {
    "PD":   ("kp", [2e3, 4e3, 6e3, 1.0e4, 1.6e4, 2.4e4],
             "kd", [1.2e4, 2.4e4, 4.0e4, 6.0e4]),
    "LQR":  ("q_swing", [1e2, 4e2, 1.6e3, 6.4e3, 2.56e4, 1e5],
             "r", [2e-8, 2e-7, 2e-6, 2e-5]),
    "ZVD":  ("kp", [2e3, 4e3, 6e3, 1.0e4, 1.6e4, 2.4e4],
             "kd", [1.2e4, 2.4e4, 4.0e4, 6.0e4]),
    "SMC":  ("c", [0.4, 0.7, 1.1, 1.6, 2.2, 3.0],
             "k", [8e3, 1.5e4, 2.2e4, 3.5e4]),
    "HSMC": ("lam", [0.1, 0.25, 0.4, 0.7, 1.2, 2.0],
             "c_swing", [0.5, 0.9, 1.3, 2.0]),
}
CLS = {"PD": PD, "LQR": LQR, "ZVD": ZVD, "SMC": SMC, "HSMC": HSMC}


def build(name, a, b, smc_gains=None):
    ka, _, kb, _ = GRIDS[name]
    kw = {ka: a, kb: b}
    if name == "HSMC" and smc_gains:
        kw.update(smc_gains)
    return CLS[name](**kw)


def score(m):
    if m is None:
        return float("inf")
    return m["peak_swing"] + 4.0 * m["residual_swing"]


def main(budget=35.0, out=ROOT / "run_retune" / "gains.json"):
    out.parent.mkdir(parents=True, exist_ok=True)
    done = json.loads(out.read_text()) if out.exists() else {}
    camp = Campaign(name="tune-stress", plant="planar", wind="none", dt=1e-2,
                    manoeuvre=STRESS).build()
    t0 = time.time()
    for name in ("PD", "LQR", "ZVD", "SMC", "HSMC"):
        if name in done:
            continue
        smc_gains = None
        if name == "HSMC" and "SMC" in done:
            smc_gains = {"c": done["SMC"]["a"], "k": done["SMC"]["b"]}
        ka, avals, kb, bvals = GRIDS[name]
        best = None
        for a in avals:
            for b in bvals:
                if time.time() - t0 > budget:
                    print(f"budget reached inside {name}; re-run to resume",
                          flush=True)
                    return
                m, _ = run_single(build(name, a, b, smc_gains), camp, None, 0)
                sc = score(m)
                if best is None or sc < best[0]:
                    best = (sc, a, b, m)
        done[name] = {"param_a": ka, "a": best[1], "param_b": kb, "b": best[2],
                      "score": best[0], "evaluations": NGRID,
                      "peak_swing": best[3]["peak_swing"],
                      "residual_swing": best[3]["residual_swing"]}
        if smc_gains:
            done[name]["inherited"] = smc_gains
        out.write_text(json.dumps(done, indent=2))
        print(f"{name}: {ka}={best[1]:g} {kb}={best[2]:g}  score={best[0]:.3f}",
              flush=True)
    print("tuning complete ->", out)


if __name__ == "__main__":
    main(float(sys.argv[1]) if len(sys.argv) > 1 else 35.0)
